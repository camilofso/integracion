/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author camilosilva
 */
public class conexion {

    private String nombreBaseDeDatos;
    private String nombreTabla;
    private String cadenaConexion;
    private String cadenaSQL;
    private boolean esSelect;
    private ResultSet dbResultSet;
    Connection dbConnection = null;
    private String usuario;
    private Statement sentencia;
    String user = "root";
    String pass = "root";
    String strconexionDB= "jdbc:mysql://localhost:3306/Prueba2";

    public Statement getSentencia() {
        return sentencia;
  
}

    public void setSentencia(Statement sentencia) {
        this.sentencia = sentencia;
    }

    public String getNombreBaseDeDatos() {
        return nombreBaseDeDatos;
    }

    public void setNombreBaseDeDatos(String nombreBaseDeDatos) {
        this.nombreBaseDeDatos = nombreBaseDeDatos;
    }

    public String getNombreTabla() {
        return nombreTabla;
    }

    public void setNombreTabla(String nombreTabla) {
        this.nombreTabla = nombreTabla;
    }

    public String getCadenaConexion() {
        return cadenaConexion;
    }

    public void setCadenaConexion(String cadenaConexion) {
        this.cadenaConexion = cadenaConexion;
    }

    public String getCadenaSQL() {
        return cadenaSQL;
    }

    public void setCadenaSQL(String cadenaSQL) {
        this.cadenaSQL = cadenaSQL;
    }

    public boolean isEsSelect() {
        return esSelect;
    }

    public void setEsSelect(boolean esSelect) {
        this.esSelect = esSelect;
    }

    public ResultSet getDbResultSet() {
        return dbResultSet;
    }

    public void setDbResultSet(ResultSet dbResultSet) {
        this.dbResultSet = dbResultSet;
    }

    public Connection getDbConnection() {
        return dbConnection;
    }

    public void setDbConnection(Connection dbConnection) {
        this.dbConnection = dbConnection;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void cerrar() {
        try {
            this.getDbConnection().close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexion " + ex.getMessage());
        }
    }

    public void conectar() {

        if (this.getNombreBaseDeDatos().length() == 0) {
            JOptionPane.showMessageDialog(null, "Falta nombre base de datos ");
        }

        if (this.getNombreTabla().length() == 0) {
            JOptionPane.showMessageDialog(null, "Falta nombre de la tabla ");
        }

        if (this.getCadenaConexion().length() == 0) {
            JOptionPane.showMessageDialog(null, "Falta cadena conexion ");
        }

        if (this.getCadenaSQL().length() == 0) {
            JOptionPane.showMessageDialog(null, "Falta cadena SQL ");
        }

        if (this.getUsuario().length() == 0) {
            JOptionPane.showMessageDialog(null, "Falta datos usuario ");
        }

        Statement st = null;
        try {

            Class.forName(this.getCadenaConexion());
            this.setDbConnection(DriverManager.getConnection(this.getNombreBaseDeDatos(), this.getUsuario(), this.getPass()));
            st = this.getDbConnection().createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la conexion " + ex.getMessage());
        }
        if (this.isEsSelect()) {

            try {
                this.setDbResultSet(st.executeQuery(this.getCadenaSQL()));
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al cargar el ResultSet " + ex.getMessage());
            }
        } else {
            try {
                int insertFila = st.executeUpdate(this.getCadenaSQL());
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error de SQL " + ex.getMessage());
            }

        }

    }
    
    public conexion(){
        
        try {
            
            dbConnection= DriverManager.getConnection(strconexionDB,user,pass);
            System.out.println("Conexion Establecida");
            
            
        } catch (Exception e) {
            System.out.println("Error de conexion " + e);
            
      
        }
    
    }
    
    
   
       public int ejecutarSentenciaSQL(String strSentenciaSQL){
        try {
            PreparedStatement pstm = dbConnection.prepareStatement(strSentenciaSQL);
            pstm.execute();
            return 1;
            
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        }
    
    }
      
    
    public ResultSet ConsultarRegistros(String strSentenciaSQL){
        try {
            PreparedStatement pstm = dbConnection.prepareStatement(strSentenciaSQL);
            ResultSet Respuesta = pstm.executeQuery();
            return Respuesta;
            
          
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
        
        
        
        
    }
    
   /* public static void main(String[] args)
    {
        conexion conec1 = new conexion();
        conec1.setNombreBaseDeDatos("jdbc:mysql://localhost/prueba2");
        conec1.setNombreTabla("ControlPeso");
        conec1.setCadenaConexion("com.mysql.jdbc.Driver");
        conec1.setUsuario("root");
        conec1.setPass("root");
        conec1.setCadenaSQL("INSERT INTO " + conec1.getNombreTabla() +
                             " (num_control, nombre, peso , altura , IMC, Resultado) VALUES (2,'camilo',80,170,210,'bien');");  
        conec1.setEsSelect(false);
        conec1.conectar();
        conec1.cerrar();
        
        
    }*/
    
    
        
    
    



}
