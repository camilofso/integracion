/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import DTO.ControlPeso;
import conexion.*;

/**
 *
 * @author camilosilva
 */
public class Negocio {
    
     private conexion conec1;

    public conexion getConec1() {
        return conec1;
    }

    /**
     * @param conec1 the conec1 to set
     */
    public void setConec1(conexion conec1) {
        this.conec1 = conec1;
    }
    
        public void configurarConexion() {
        this.setConec1(new conexion());
        this.getConec1().setNombreBaseDeDatos("jdbc:mysql://localhost/Prueba2");
        this.getConec1().setNombreTabla("ControlPeso");
        this.getConec1().setCadenaConexion("com.mysql.jdbc.Driver");
        this.getConec1().setUsuario("root");
        this.getConec1().setPass("root");
  
        
        }
        
        
        
        public void RegistraControlPEso(ControlPeso auxControlPeso) {

        conexion auxconexion = new conexion();
        String strSentenciaInsert = String.format("INSERT INTO ControlPeso (num_control, nombre, peso, altura, IMC, Resultado) "
                + "VALUES ('" + auxControlPeso.getNumControl()+ "','" + auxControlPeso.getNombre()+ "','" + auxControlPeso.getPeso()+ "','" + auxControlPeso.getAltura()+ "','" + auxControlPeso.getIMC()+ "','", auxControlPeso.getResultado()+"')", auxControlPeso.getNumControl(), auxControlPeso.getNombre(), auxControlPeso.getPeso(), auxControlPeso.getAltura(), auxControlPeso.getIMC(),auxControlPeso.getResultado());

        auxconexion.ejecutarSentenciaSQL(strSentenciaInsert);
        this.getConec1().setEsSelect(false);
        this.getConec1().conectar();
       
    }
}
